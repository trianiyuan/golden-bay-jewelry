# 💍 Golden Bay Jewelry App

> Sistema de gestión de inventario, ventas y finanzas para Golden Bay Jewelry — joyería costarricense especializada en accesorios dorados, plateados y rose gold.

**🌐 Live Demo:** [app.goldenbayjewelry.com](https://app.goldenbayjewelry.com)

---

## 📸 Screenshots

> _Agregar capturas de pantalla del Dashboard, Inventario, Ventas y PDF aquí_

| Dashboard | Inventario | Ventas | Finanzas |
|-----------|-----------|--------|---------|
| ![Dashboard](screenshots/dashboard.png) | ![Inventario](screenshots/inventory.png) | ![Ventas](screenshots/sales.png) | ![Finanzas](screenshots/finances.png) |

---

## 🚀 Features

### 📦 Inventario
- Gestión completa de productos con foto, categoría, talla y color
- Filtros por categoría, color y tipo de arete (Regular / Ear Cuff)
- Control de stock con alertas de inventario bajo
- Archivar y reactivar productos sin perder historial de ventas
- Historial de movimientos por producto

### 🛍️ Ventas
- Registro de ventas en 3 pasos con carrito de productos
- Selección de canal de venta con comisión automática
- Badge de comisión aplicada por venta
- Método de entrega (Correos CR / Retiro personal)
- Edición y eliminación de ventas registradas

### 💰 Finanzas
- Dashboard financiero con métricas del mes
- Gráfico histórico de ganancias (últimos 5 meses)
- KPIs: margen bruto %, margen neto %, ticket promedio
- Reporte PDF mensual y anual con un click
- Rango de fechas personalizado en reportes
- Desglose automático de comisiones por canal en PDF

### 📊 Reportes PDF
- Resumen financiero con KPIs
- Estado de resultados con comisiones y costos fijos deducidos
- Ventas por canal de venta
- Top 5 productos más vendidos
- Top 5 productos con menor rotación (slow movers)
- Valor del inventario a precio de costo
- Resumen por mes (reporte anual)

### ⚙️ Configuración
- Categorías y tallas personalizables
- Canales de venta con comisión % y costo fijo mensual
- Categorías de gasto
- Todo configurable sin tocar código

### 🔒 Seguridad
- Autenticación con Supabase Auth
- Row Level Security (RLS) en todas las tablas
- Vistas protegidas con `security_invoker`
- Variables de entorno para credenciales

---

## 🛠️ Tech Stack

| Capa | Tecnología |
|------|-----------|
| Frontend | React Native + Expo (web) |
| Backend | Supabase (PostgreSQL) |
| Auth | Supabase Auth |
| Storage | Supabase Storage |
| Deploy | Vercel |
| Dominio | goldenbayjewelry.com |

---

## 📁 Estructura del Proyecto

```
gb-joyas/
├── app/
│   ├── (auth)/login.tsx          # Login
│   ├── (tabs)/
│   │   ├── index.tsx             # Dashboard
│   │   ├── inventory.tsx         # Inventario
│   │   ├── sales.tsx             # Ventas
│   │   ├── finances.tsx          # Finanzas + PDF
│   │   └── expenses.tsx          # Gastos
│   ├── product/[id].tsx          # Detalle producto
│   ├── sale/new.tsx              # Nueva venta
│   └── settings.tsx              # Configuración
├── components/
│   ├── inventory/ProductCard.tsx
│   └── ui/
├── lib/
│   ├── queries/                  # Queries a Supabase
│   ├── generatePDF.ts            # Generador PDF
│   └── supabase.ts
├── stores/                       # Zustand stores
├── types/index.ts
└── constants/colors.ts
```

---

## ⚡ Setup Local

```bash
# Clonar
git clone https://github.com/trianiyuan/gb-joyas.git
cd gb-joyas/gb-joyas

# Instalar dependencias
npm install --legacy-peer-deps

# Variables de entorno
cp .env.example .env.local
# Editar .env.local con tus credenciales de Supabase

# Correr
npm run web
```

### Variables de entorno

```env
EXPO_PUBLIC_SUPABASE_URL=tu_supabase_url
EXPO_PUBLIC_SUPABASE_ANON_KEY=tu_anon_key
```

---

## 🗄️ Base de Datos

### Tablas principales

| Tabla | Descripción |
|-------|------------|
| `productos` | Inventario de joyas |
| `categorias` | Tipos de joya |
| `tallas_por_categoria` | Tallas por categoría |
| `ventas` | Registro de ventas |
| `ventas_productos` | Detalle de productos por venta |
| `gastos` | Gastos operativos |
| `canales_venta` | Canales con comisión y costo fijo |
| `movimientos_inventario` | Historial de stock |

### Vistas

| Vista | Descripción |
|-------|------------|
| `resumen_mensual` | Métricas financieras por mes |
| `gastos_por_mes` | Gastos agrupados por mes |
| `productos_mas_vendidos` | Top productos por ventas |
| `stock_por_categoria` | Stock agrupado por categoría |

---

## 🚀 Deploy

El proyecto usa deploy automático con Vercel. Cada `git push` a `main` genera un nuevo deployment.

```bash
git add .
git commit -m "feat: descripción del cambio"
git push
```

---

## 📋 Roadmap

- [ ] Importación masiva de inventario desde CSV
- [ ] Notificaciones push de stock bajo
- [ ] Análisis de tendencias por temporada
- [ ] App nativa iOS/Android
- [ ] Multi-usuario con roles

---

## 👩‍💻 Desarrollado por

**Trianiyuan** — Full Stack Developer  
📧 [goldenbayjewelrycr@gmail.com](mailto:goldenbayjewelrycr@gmail.com)  
🌐 [app.goldenbayjewelry.com](https://app.goldenbayjewelry.com)

---

## 📄 Licencia

Proyecto privado — todos los derechos reservados © 2026 Golden Bay Jewelry
