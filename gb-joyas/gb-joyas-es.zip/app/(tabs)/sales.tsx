// app/tabs/sales.tsx
import React, { useState, useCallback } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, SafeAreaView } from 'react-native';
import { useRouter, useFocusEffect } from 'expo-router';
import { getVentas } from '../../lib/queries/sales';
import { Venta } from '../../types';
import { COLORS, SIZES } from '../../constants/colors';
import { Header } from '../../components/ui/Header';

const MESES = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];

export default function SalesScreen() {
  const router = useRouter();
  const [ventas, setVentas] = useState<Venta[]>([]);
  const [loading, setLoading] = useState(true);
  const [mes, setMes] = useState(new Date());

  const cargar = useCallback(async () => {
    setLoading(true);
    try { setVentas(await getVentas(mes)); }
    finally { setLoading(false); }
  }, [mes]);

  useFocusEffect(cargar);

  function cambiarMes(delta: number) {
    setMes(prev => new Date(prev.getFullYear(), prev.getMonth() + delta, 1));
  }

  const totalMes = ventas.reduce((sum, v) => sum + Number(v.total_cobrado), 0);

  return (
    <SafeAreaView style={styles.safe}>
      <Header
        title="Ventas"
        rightElement={
          <View style={styles.headerButtons}>
            <TouchableOpacity style={styles.btnSecondary}>
              <Text style={styles.btnSecondaryText}>Editar</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.btnPrimary} onPress={() => router.push('/sale/new')} activeOpacity={0.85}>
              <Text style={styles.btnPrimaryText}>+ Nueva</Text>
            </TouchableOpacity>
          </View>
        }
      />

      <View style={styles.mesSelector}>
        <TouchableOpacity onPress={() => cambiarMes(-1)} style={styles.mesBtn}>
          <Text style={styles.mesBtnText}>‹</Text>
        </TouchableOpacity>
        <Text style={styles.mesNombre}>{MESES[mes.getMonth()]} {mes.getFullYear()}</Text>
        <TouchableOpacity onPress={() => cambiarMes(1)} style={styles.mesBtn}>
          <Text style={styles.mesBtnText}>›</Text>
        </TouchableOpacity>
      </View>

      {ventas.length > 0 && (
        <View style={styles.resumenBar}>
          <Text style={styles.resumenText}>{ventas.length} venta{ventas.length > 1 ? 's' : ''}</Text>
          <Text style={styles.resumenTotal}>₡{totalMes.toLocaleString('es-CR')}</Text>
        </View>
      )}

      <ScrollView style={styles.scroll} contentContainerStyle={styles.content}>
        {ventas.map(venta => (
          <TouchableOpacity key={venta.id} style={styles.ventaCard} activeOpacity={0.85}>
            <View style={styles.avatar}>
              <Text style={styles.avatarText}>{venta.cliente_nombre.slice(0, 2).toUpperCase()}</Text>
            </View>
            <View style={styles.ventaInfo}>
              <Text style={styles.ventaNombre}>{venta.cliente_nombre}</Text>
              <Text style={styles.ventaDetalle} numberOfLines={1}>
                {venta.productos?.length || 0} producto{(venta.productos?.length || 0) > 1 ? 's' : ''} ·{' '}
                {venta.metodo_entrega === 'correos_cr' ? 'Correos CR' : 'Retiro personal'} ·{' '}
                {new Date(venta.fecha).toLocaleDateString('es-CR', { day: 'numeric', month: 'short' })}
              </Text>
              {(venta as any).canal_venta?.nombre && (
                <View style={styles.canalBadge}>
                  <Text style={styles.canalText}>{(venta as any).canal_venta.nombre}</Text>
                </View>
              )}
              {venta.notas ? <Text style={styles.ventaNota} numberOfLines={1}>💬 {venta.notas}</Text> : null}
            </View>
            <View style={styles.ventaMonto}>
              <Text style={styles.ventaMontoText}>₡{Math.round(Number(venta.total_cobrado) / 1000)}k</Text>
              {Number(venta.total_recibido) < Number(venta.total_cobrado) && (
                <View style={styles.pendienteBadge}><Text style={styles.pendienteText}>Pendiente</Text></View>
              )}
            </View>
          </TouchableOpacity>
        ))}

        {ventas.length === 0 && !loading && (
          <View style={styles.empty}>
            <Text style={styles.emptyIcon}>🛍️</Text>
            <Text style={styles.emptyText}>Sin ventas en {MESES[mes.getMonth()]}</Text>
            <TouchableOpacity style={styles.emptyBtn} onPress={() => router.push('/sale/new')}>
              <Text style={styles.emptyBtnText}>Registrar primera venta</Text>
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.surface },
  headerButtons: { flexDirection: 'row', gap: 6 },
  btnPrimary: { backgroundColor: COLORS.wine, borderRadius: SIZES.radiusSm, paddingVertical: 7, paddingHorizontal: 11 },
  btnPrimaryText: { fontSize: 12, fontWeight: '600', color: COLORS.surface },
  btnSecondary: { backgroundColor: COLORS.surfaceAlt, borderRadius: SIZES.radiusSm, paddingVertical: 7, paddingHorizontal: 11, borderWidth: 1, borderColor: COLORS.border },
  btnSecondaryText: { fontSize: 12, fontWeight: '500', color: COLORS.textPrimary },
  mesSelector: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: COLORS.surfaceAlt, paddingHorizontal: SIZES.lg, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  mesBtn: { backgroundColor: COLORS.surface, borderRadius: SIZES.radiusSm, borderWidth: 1, borderColor: COLORS.border, paddingHorizontal: 10, paddingVertical: 4 },
  mesBtnText: { fontSize: 18, color: COLORS.textPrimary },
  mesNombre: { fontSize: 14, fontWeight: '600', color: COLORS.textPrimary },
  resumenBar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: COLORS.blush, paddingHorizontal: SIZES.lg, paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  resumenText: { fontSize: 12, color: COLORS.textMuted },
  resumenTotal: { fontSize: 14, fontWeight: '600', color: COLORS.textPrimary },
  scroll: { flex: 1, backgroundColor: COLORS.background },
  content: { padding: SIZES.lg },
  ventaCard: { backgroundColor: COLORS.surface, borderRadius: SIZES.radiusMd, padding: 12, borderWidth: 1, borderColor: COLORS.border, marginBottom: 8, flexDirection: 'row', alignItems: 'center', gap: 12 },
  avatar: { width: 38, height: 38, borderRadius: 19, backgroundColor: COLORS.blush, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  avatarText: { fontSize: 12, fontWeight: '600', color: COLORS.wine },
  ventaInfo: { flex: 1 },
  ventaNombre: { fontSize: 13, fontWeight: '600', color: COLORS.textPrimary },
  ventaDetalle: { fontSize: 11, color: COLORS.textMuted, marginTop: 2 },
  canalBadge: { alignSelf: 'flex-start', marginTop: 3, backgroundColor: COLORS.surfaceAlt, borderRadius: SIZES.radiusFull, paddingHorizontal: 8, paddingVertical: 2, borderWidth: 1, borderColor: COLORS.border },
  canalText: { fontSize: 10, color: COLORS.textMuted, fontWeight: '500' },
  ventaNota: { fontSize: 11, color: COLORS.textMuted, marginTop: 2, fontStyle: 'italic' },
  ventaMonto: { alignItems: 'flex-end', gap: 4 },
  ventaMontoText: { fontSize: 14, fontWeight: '600', color: COLORS.textPrimary },
  pendienteBadge: { backgroundColor: COLORS.rose, borderRadius: SIZES.radiusFull, paddingHorizontal: 6, paddingVertical: 2 },
  pendienteText: { fontSize: 10, color: COLORS.wine, fontWeight: '500' },
  empty: { alignItems: 'center', paddingTop: 60, gap: 12 },
  emptyIcon: { fontSize: 48 },
  emptyText: { fontSize: 14, color: COLORS.textMuted },
  emptyBtn: { backgroundColor: COLORS.wine, borderRadius: SIZES.radiusMd, paddingVertical: 10, paddingHorizontal: 20, marginTop: 8 },
  emptyBtnText: { color: COLORS.surface, fontSize: 13, fontWeight: '600' },
});
