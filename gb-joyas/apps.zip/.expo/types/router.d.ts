/* eslint-disable */
import * as Router from 'expo-router';

export * from 'expo-router';

declare module 'expo-router' {
  export namespace ExpoRouter {
    export interface __routes<T extends string = string> extends Record<string, unknown> {
      StaticRoutes: `/` | `/(auth)` | `/(auth)/login` | `/(tabs)` | `/(tabs)/` | `/(tabs)/expenses` | `/(tabs)/finances` | `/(tabs)/inventory` | `/(tabs)/sales` | `/_sitemap` | `/expense/new` | `/expenses` | `/finances` | `/inventory` | `/login` | `/product/new` | `/sale/new` | `/sales`;
      DynamicRoutes: `/product/${Router.SingleRoutePart<T>}`;
      DynamicRouteTemplate: `/product/[id]`;
    }
  }
}
