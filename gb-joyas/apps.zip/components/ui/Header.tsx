// components/ui/Header.tsx
import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';
import { useRouter } from 'expo-router';
import { COLORS, SIZES } from '../../constants/colors';

interface HeaderProps {
  showBack?: boolean;
  backLabel?: string;
  title?: string;
  rightElement?: React.ReactNode;
}

export function Header({ showBack, backLabel = '‹ Back', title, rightElement }: HeaderProps) {
  const router = useRouter();

  return (
    <View style={styles.header}>
      {/* Left — GB monogram or back button */}
      {showBack ? (
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Text style={styles.backText}>{backLabel}</Text>
        </TouchableOpacity>
      ) : (
        <TouchableOpacity onPress={() => router.replace('/(tabs)')} style={styles.logoCircle}>
          <Text style={styles.logoMono}>GB</Text>
        </TouchableOpacity>
      )}

      {/* Center — Golden Bay Jewelry wordmark or custom title */}
      <View style={styles.centerContainer}>
        {title ? (
          <Text style={styles.pageTitle}>{title}</Text>
        ) : (
          <View style={styles.wordmark}>
            <Text style={styles.wordmarkMain}>Golden Bay</Text>
            <Text style={styles.wordmarkSub}>JEWELRY</Text>
          </View>
        )}
      </View>

      {/* Right — optional element */}
      <View style={styles.right}>
        {rightElement || <View style={{ width: 40 }} />}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    backgroundColor: COLORS.surface,
    paddingHorizontal: SIZES.lg,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  // GB monogram circle
  logoCircle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: COLORS.blush,
    borderWidth: 1,
    borderColor: COLORS.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoMono: {
    fontSize: 14,
    fontWeight: '700',
    color: COLORS.wine,
    letterSpacing: 0.5,
  },
  // Back button
  backBtn: {
    paddingVertical: 4,
    paddingRight: 8,
    minWidth: 40,
  },
  backText: {
    fontSize: 14,
    color: COLORS.wine,
    fontWeight: '500',
  },
  // Center
  centerContainer: {
    flex: 1,
    alignItems: 'center',
  },
  wordmark: {
    alignItems: 'center',
  },
  wordmarkMain: {
    fontSize: 18,
    fontWeight: '700',
    color: COLORS.wine,
    letterSpacing: 0.3,
  },
  wordmarkSub: {
    fontSize: 9,
    fontWeight: '600',
    color: COLORS.textMuted,
    letterSpacing: 2.5,
    marginTop: -2,
  },
  pageTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.textPrimary,
  },
  right: {
    minWidth: 40,
    alignItems: 'flex-end',
  },
});
