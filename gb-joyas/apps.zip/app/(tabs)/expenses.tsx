// app/tabs/expenses.tsx
import React, { useState, useCallback } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  StyleSheet, SafeAreaView, Modal, Alert, ActivityIndicator,
} from 'react-native';
import { useFocusEffect } from 'expo-router';
import { useForm, Controller } from 'react-hook-form';
import { getGastos, createGasto, getCategoriasGasto } from '../../lib/queries/sales';
import { Gasto, CategoriaGasto } from '../../types';
import { COLORS, SIZES } from '../../constants/colors';
import { Input } from '../../components/ui/Input';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

type FormData = { monto: string; notas: string; };

export default function ExpensesScreen() {
  const [gastos, setGastos] = useState<Gasto[]>([]);
  const [categorias, setCategorias] = useState<CategoriaGasto[]>([]);
  const [mes, setMes] = useState(new Date());
  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [catSeleccionada, setCatSeleccionada] = useState('');
  const [saving, setSaving] = useState(false);

  const { control, handleSubmit, reset, formState: { errors } } = useForm<FormData>({
    defaultValues: { monto: '', notas: '' },
  });

  const cargar = useCallback(async () => {
    setLoading(true);
    try {
      const [g, c] = await Promise.all([getGastos(mes), getCategoriasGasto()]);
      setGastos(g);
      setCategorias(c);
      if (c.length > 0 && !catSeleccionada) setCatSeleccionada(c[0].id);
    } finally {
      setLoading(false);
    }
  }, [mes]);

  useFocusEffect(cargar);

  function cambiarMes(delta: number) {
    setMes(prev => new Date(prev.getFullYear(), prev.getMonth() + delta, 1));
  }

  async function guardarGasto(data: FormData) {
    if (!catSeleccionada) { Alert.alert('Selecciona una categoría'); return; }
    try {
      setSaving(true);
      await createGasto({
        monto: parseFloat(data.monto),
        notas: data.notas.trim() || undefined,
        categoria_gasto_id: catSeleccionada,
        fecha: new Date().toISOString().split('T')[0],
      });
      reset();
      setModalVisible(false);
      cargar();
    } catch (e: any) {
      Alert.alert('Error', e.message);
    } finally {
      setSaving(false);
    }
  }

  const totalMes = gastos.reduce((sum, g) => sum + Number(g.monto), 0);

  // Agrupar por categoría para el resumen
  const porCategoria: Record<string, number> = {};
  gastos.forEach(g => {
    const nombre = g.categoria?.nombre || 'Otros';
    porCategoria[nombre] = (porCategoria[nombre] || 0) + Number(g.monto);
  });

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Gastos</Text>
        <TouchableOpacity
          style={styles.btnAgregar}
          onPress={() => setModalVisible(true)}
          activeOpacity={0.85}
        >
          <Text style={styles.btnAgregarText}>+ Agregar</Text>
        </TouchableOpacity>
      </View>

      {/* Selector mes */}
      <View style={styles.mesSelector}>
        <TouchableOpacity onPress={() => cambiarMes(-1)} style={styles.mesBtn}>
          <Text style={styles.mesBtnText}>‹</Text>
        </TouchableOpacity>
        <Text style={styles.mesNombre}>
          {format(mes, 'MMMM yyyy', { locale: es })}
        </Text>
        <TouchableOpacity onPress={() => cambiarMes(1)} style={styles.mesBtn}>
          <Text style={styles.mesBtnText}>›</Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.scroll} contentContainerStyle={styles.content}>
        {/* Resumen total */}
        <View style={styles.totalCard}>
          <View>
            <Text style={styles.totalLabel}>TOTAL GASTOS</Text>
            <Text style={styles.totalMonto}>₡{totalMes.toLocaleString('es-CR')}</Text>
          </View>
          {/* Mini desglose */}
          <View style={styles.desglose}>
            {Object.entries(porCategoria).map(([nombre, monto]) => (
              <View key={nombre} style={styles.desgloseItem}>
                <View style={styles.desgloseDot} />
                <Text style={styles.desgloseNombre} numberOfLines={1}>{nombre}</Text>
                <Text style={styles.desgloseMonto}>₡{Math.round(monto / 1000)}k</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Historial */}
        <Text style={styles.sectionTitle}>HISTORIAL</Text>
        {gastos.map(gasto => (
          <View key={gasto.id} style={styles.gastoItem}>
            <View style={styles.gastoIcon}>
              <Text style={{ fontSize: 18 }}>
                {gasto.categoria?.nombre?.includes('Compra') ? '📦'
                  : gasto.categoria?.nombre?.includes('Envío') ? '🚚'
                  : gasto.categoria?.nombre?.includes('Empaque') ? '🎁' : '💰'}
              </Text>
            </View>
            <View style={styles.gastoInfo}>
              <Text style={styles.gastoCategoria}>{gasto.categoria?.nombre}</Text>
              {gasto.notas ? (
                <Text style={styles.gastoNota} numberOfLines={1}>{gasto.notas}</Text>
              ) : null}
              <Text style={styles.gastoFecha}>
                {format(new Date(gasto.fecha + 'T12:00:00'), 'd MMM yyyy', { locale: es })}
              </Text>
            </View>
            <Text style={styles.gastoMonto}>₡{Number(gasto.monto).toLocaleString('es-CR')}</Text>
          </View>
        ))}

        {gastos.length === 0 && !loading && (
          <View style={styles.empty}>
            <Text style={styles.emptyIcon}>📋</Text>
            <Text style={styles.emptyText}>No hay gastos en {format(mes, 'MMMM', { locale: es })}</Text>
          </View>
        )}
      </ScrollView>

      {/* Modal agregar gasto */}
      <Modal visible={modalVisible} animationType="slide" presentationStyle="pageSheet">
        <SafeAreaView style={styles.modal}>
          <View style={styles.modalHeader}>
            <TouchableOpacity onPress={() => { setModalVisible(false); reset(); }}>
              <Text style={styles.modalCancelar}>Cancelar</Text>
            </TouchableOpacity>
            <Text style={styles.modalTitulo}>Nuevo gasto</Text>
            <View style={{ width: 60 }} />
          </View>

          <ScrollView style={{ flex: 1 }} contentContainerStyle={styles.content}>
            <Text style={styles.fieldLabel}>CATEGORÍA</Text>
            <View style={styles.catGrid}>
              {categorias.map(c => (
                <TouchableOpacity
                  key={c.id}
                  style={[styles.catChip, catSeleccionada === c.id && styles.catChipActive]}
                  onPress={() => setCatSeleccionada(c.id)}
                >
                  <Text style={[styles.catChipText, catSeleccionada === c.id && styles.catChipTextActive]}>
                    {c.nombre}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            <Controller
              control={control}
              name="monto"
              rules={{ required: 'El monto es obligatorio', pattern: { value: /^\d+(\.\d{1,2})?$/, message: 'Monto inválido' } }}
              render={({ field: { onChange, value } }) => (
                <Input label="Monto (₡)" value={value} onChangeText={onChange}
                  keyboardType="numeric" placeholder="45000" error={errors.monto?.message} />
              )}
            />

            <Controller
              control={control}
              name="notas"
              render={({ field: { onChange, value } }) => (
                <Input label="Notas (opcional)" value={value} onChangeText={onChange}
                  placeholder="Ej: compré 10 pares a la proveedora"
                  multiline numberOfLines={3} style={{ height: 80, textAlignVertical: 'top' }} />
              )}
            />
          </ScrollView>

          <View style={styles.modalFooter}>
            <TouchableOpacity
              style={[styles.saveBtn, saving && { opacity: 0.7 }]}
              onPress={handleSubmit(guardarGasto)}
              disabled={saving}
            >
              {saving
                ? <ActivityIndicator color={COLORS.surface} />
                : <Text style={styles.saveBtnText}>Guardar gasto</Text>
              }
            </TouchableOpacity>
          </View>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.surface },
  header: {
    backgroundColor: COLORS.surface,
    paddingHorizontal: SIZES.xl, paddingVertical: SIZES.lg,
    borderBottomWidth: 1, borderBottomColor: COLORS.border,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
  },
  headerTitle: { fontSize: 17, fontWeight: '600', color: COLORS.textPrimary },
  btnAgregar: { backgroundColor: COLORS.wine, borderRadius: SIZES.radiusSm, paddingVertical: 8, paddingHorizontal: 13 },
  btnAgregarText: { fontSize: 12, fontWeight: '600', color: COLORS.surface },

  mesSelector: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: COLORS.surfaceAlt, paddingHorizontal: SIZES.lg, paddingVertical: 10,
    borderBottomWidth: 1, borderBottomColor: COLORS.border,
  },
  mesBtn: { backgroundColor: COLORS.surface, borderRadius: SIZES.radiusSm, borderWidth: 1, borderColor: COLORS.border, paddingHorizontal: 10, paddingVertical: 4 },
  mesBtnText: { fontSize: 18, color: COLORS.textPrimary },
  mesNombre: { fontSize: 14, fontWeight: '600', color: COLORS.textPrimary, textTransform: 'capitalize' },

  scroll: { flex: 1, backgroundColor: COLORS.background },
  content: { padding: SIZES.lg },

  totalCard: {
    backgroundColor: COLORS.blush, borderRadius: SIZES.radiusLg,
    padding: 16, borderWidth: 1, borderColor: COLORS.border, marginBottom: 16,
  },
  totalLabel: { fontSize: SIZES.textXs, color: COLORS.textMuted, letterSpacing: 0.7, marginBottom: 4 },
  totalMonto: { fontSize: 28, fontWeight: '600', color: COLORS.textPrimary, marginBottom: 12 },
  desglose: { gap: 6 },
  desgloseItem: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  desgloseDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: COLORS.wine },
  desgloseNombre: { flex: 1, fontSize: 12, color: COLORS.textMuted },
  desgloseMonto: { fontSize: 12, fontWeight: '600', color: COLORS.textPrimary },

  sectionTitle: { fontSize: SIZES.textXs, fontWeight: '600', color: COLORS.textMuted, letterSpacing: 0.8, marginBottom: 10 },

  gastoItem: {
    backgroundColor: COLORS.surface, borderRadius: SIZES.radiusMd,
    padding: 12, borderWidth: 1, borderColor: COLORS.border,
    marginBottom: 8, flexDirection: 'row', alignItems: 'center', gap: 12,
  },
  gastoIcon: { width: 38, height: 38, borderRadius: 19, backgroundColor: COLORS.blush, alignItems: 'center', justifyContent: 'center' },
  gastoInfo: { flex: 1 },
  gastoCategoria: { fontSize: 13, fontWeight: '600', color: COLORS.textPrimary },
  gastoNota: { fontSize: 11, color: COLORS.textMuted, marginTop: 2, fontStyle: 'italic' },
  gastoFecha: { fontSize: 11, color: COLORS.textMuted, marginTop: 2 },
  gastoMonto: { fontSize: 14, fontWeight: '600', color: COLORS.textPrimary },

  empty: { alignItems: 'center', paddingTop: 60, gap: 12 },
  emptyIcon: { fontSize: 48 },
  emptyText: { fontSize: 14, color: COLORS.textMuted, textTransform: 'capitalize' },

  modal: { flex: 1, backgroundColor: COLORS.background },
  modalHeader: {
    backgroundColor: COLORS.surface, paddingHorizontal: SIZES.xl, paddingVertical: SIZES.lg,
    borderBottomWidth: 1, borderBottomColor: COLORS.border,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
  },
  modalCancelar: { fontSize: 14, color: COLORS.wine, fontWeight: '500' },
  modalTitulo: { fontSize: 15, fontWeight: '600', color: COLORS.textPrimary },
  modalFooter: { padding: 12, paddingHorizontal: SIZES.lg, backgroundColor: COLORS.surface, borderTopWidth: 1, borderTopColor: COLORS.border },
  saveBtn: { backgroundColor: COLORS.wine, borderRadius: SIZES.radiusMd, paddingVertical: 14, alignItems: 'center' },
  saveBtnText: { color: COLORS.surface, fontSize: 15, fontWeight: '600' },

  fieldLabel: { fontSize: SIZES.textXs, fontWeight: '600', color: COLORS.textMuted, letterSpacing: 0.7, marginBottom: 8 },
  catGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 16 },
  catChip: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: SIZES.radiusFull, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.surfaceAlt },
  catChipActive: { backgroundColor: COLORS.wine, borderColor: COLORS.wine },
  catChipText: { fontSize: 12, fontWeight: '500', color: COLORS.textPrimary },
  catChipTextActive: { color: COLORS.surface },
});
