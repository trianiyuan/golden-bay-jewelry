// app/tabs/index.tsx
import React, { useEffect, useState, useCallback } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  StyleSheet, SafeAreaView,
} from 'react-native';
import { useRouter, useFocusEffect } from 'expo-router';
import { COLORS, SIZES } from '../../constants/colors';
import { Header } from '../../components/ui/Header';
import { getProductosStockBajo } from '../../lib/queries/products';
import { getVentas } from '../../lib/queries/sales';
import { getResumenMes } from '../../lib/queries/finances';
import { Venta, Producto, ResumenMes } from '../../types';

export default function DashboardScreen() {
  const router = useRouter();
  const [ventas, setVentas] = useState<Venta[]>([]);
  const [stockBajo, setStockBajo] = useState<Producto[]>([]);
  const [resumen, setResumen] = useState<ResumenMes | null>(null);
  const [loading, setLoading] = useState(true);
  const hoy = new Date();

  const cargar = useCallback(async () => {
    try {
      const [v, sb, r] = await Promise.all([
        getVentas(hoy),
        getProductosStockBajo(3),
        getResumenMes(hoy.getFullYear(), hoy.getMonth()),
      ]);
      setVentas(v);
      setStockBajo(sb);
      setResumen(r);
    } finally {
      setLoading(false);
    }
  }, []);

  useFocusEffect(cargar);

  const ultimasVentas = ventas.slice(0, 3);

  return (
    <SafeAreaView style={styles.safe}>
      <Header />

      <ScrollView style={styles.scroll} contentContainerStyle={styles.content}>
        {/* Metrics */}
        <View style={styles.metricsGrid}>
          <View style={styles.metricCard}>
            <Text style={styles.metricLabel}>PRODUCTS</Text>
            <Text style={styles.metricValue}>
              {loading ? '—' : ventas.length > 0 ? ventas.length : '0'}
            </Text>
            <Text style={styles.metricSub}>in inventory</Text>
          </View>

          <View style={[styles.metricCard, styles.metricAccent]}>
            <Text style={styles.metricLabel}>MONTHLY SALES</Text>
            <Text style={styles.metricValue}>{loading ? '—' : ventas.length}</Text>
            <Text style={styles.metricSub}>
              ₡{(resumen?.ingresos_ventas || 0).toLocaleString('es-CR')}
            </Text>
          </View>

          <View style={[styles.metricCard, styles.metricAccent]}>
            <Text style={styles.metricLabel}>PROFIT</Text>
            <Text style={styles.metricValue}>
              ₡{Math.round((resumen?.ganancia || 0) / 1000)}k
            </Text>
            <Text style={styles.metricSub}>this month</Text>
          </View>

          {/* Stock bajo — clickeable → inventory con filtro */}
          <TouchableOpacity
            style={[styles.metricCard, styles.metricWarn]}
            onPress={() => router.push('/(tabs)/inventory?filter=stock_bajo')}
            activeOpacity={0.85}
          >
            <Text style={styles.metricLabel}>LOW STOCK</Text>
            <Text style={[styles.metricValue, { color: COLORS.wine }]}>
              {loading ? '—' : stockBajo.length}
            </Text>
            <Text style={[styles.metricSub, { color: COLORS.wine, fontWeight: '600' }]}>
              {stockBajo.length > 0 ? 'tap to review ›' : 'all good ✓'}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Recent sales */}
        <Text style={styles.sectionTitle}>RECENT SALES</Text>
        {ultimasVentas.map(venta => (
          <View key={venta.id} style={styles.ventaItem}>
            <View style={styles.ventaAvatar}>
              <Text style={styles.ventaAvatarText}>
                {venta.cliente_nombre.slice(0, 2).toUpperCase()}
              </Text>
            </View>
            <View style={styles.ventaInfo}>
              <Text style={styles.ventaNombre}>{venta.cliente_nombre}</Text>
              <Text style={styles.ventaDetalle} numberOfLines={1}>
                {venta.metodo_entrega === 'correos_cr' ? 'Correos CR' : 'Personal pickup'}
                {(venta as any).canal_venta?.nombre ? ` · ${(venta as any).canal_venta.nombre}` : ''}
              </Text>
            </View>
            <Text style={styles.ventaMonto}>
              ₡{Math.round(Number(venta.total_cobrado) / 1000)}k
            </Text>
          </View>
        ))}

        {ultimasVentas.length === 0 && !loading && (
          <View style={styles.emptyCard}>
            <Text style={styles.emptyText}>No sales this month yet</Text>
          </View>
        )}
      </ScrollView>

      {/* Footer buttons */}
      <View style={styles.fabRow}>
        <TouchableOpacity
          style={styles.fabPrimary}
          onPress={() => router.push('/sale/new')}
          activeOpacity={0.85}
        >
          <Text style={styles.fabPrimaryText}>+ Register sale</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.fabSecondary}
          onPress={() => router.push('/(tabs)/inventory')}
          activeOpacity={0.85}
        >
          <Text style={styles.fabSecondaryText}>View inventory</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.surface },
  scroll: { flex: 1 },
  content: { padding: SIZES.lg, paddingBottom: SIZES.xxl },

  metricsGrid: {
    flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: SIZES.lg,
  },
  metricCard: {
    width: '47.5%', backgroundColor: COLORS.surface,
    borderRadius: SIZES.radiusLg, padding: 14,
    borderWidth: 1, borderColor: COLORS.border,
  },
  metricAccent: { backgroundColor: COLORS.blush, borderColor: COLORS.peach },
  metricWarn: { backgroundColor: COLORS.surface, borderColor: COLORS.wine },
  metricLabel: {
    fontSize: SIZES.textXs, color: COLORS.textMuted,
    letterSpacing: 0.7, marginBottom: 6,
  },
  metricValue: { fontSize: SIZES.textH2, fontWeight: '600', color: COLORS.textPrimary },
  metricSub: { fontSize: SIZES.textSm, color: COLORS.textMuted, marginTop: 3 },

  sectionTitle: {
    fontSize: SIZES.textXs, fontWeight: '600', color: COLORS.textMuted,
    letterSpacing: 0.8, marginBottom: 10, marginTop: SIZES.lg,
  },

  ventaItem: {
    backgroundColor: COLORS.surface, borderRadius: SIZES.radiusMd,
    padding: 12, borderWidth: 1, borderColor: COLORS.border,
    marginBottom: 8, flexDirection: 'row', alignItems: 'center', gap: 12,
  },
  ventaAvatar: {
    width: 34, height: 34, borderRadius: 17,
    backgroundColor: COLORS.blush, alignItems: 'center', justifyContent: 'center',
  },
  ventaAvatarText: { fontSize: 12, fontWeight: '600', color: COLORS.wine },
  ventaInfo: { flex: 1 },
  ventaNombre: { fontSize: 13, fontWeight: '600', color: COLORS.textPrimary },
  ventaDetalle: { fontSize: 11, color: COLORS.textMuted, marginTop: 2 },
  ventaMonto: { fontSize: 14, fontWeight: '600', color: COLORS.textPrimary },

  emptyCard: {
    backgroundColor: COLORS.surface, borderRadius: SIZES.radiusMd,
    padding: 24, borderWidth: 1, borderColor: COLORS.border, alignItems: 'center',
  },
  emptyText: { color: COLORS.textMuted, fontSize: 13 },

  fabRow: {
    flexDirection: 'row', gap: 8, padding: 12, paddingHorizontal: SIZES.lg,
    backgroundColor: COLORS.surface, borderTopWidth: 1, borderTopColor: COLORS.border,
  },
  fabPrimary: {
    flex: 1, backgroundColor: COLORS.wine, borderRadius: SIZES.radiusMd,
    paddingVertical: 12, alignItems: 'center', justifyContent: 'center',
  },
  fabPrimaryText: { color: COLORS.surface, fontSize: 13, fontWeight: '600' },
  fabSecondary: {
    flex: 1, backgroundColor: COLORS.surface, borderRadius: SIZES.radiusMd,
    paddingVertical: 12, alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: COLORS.border,
  },
  fabSecondaryText: { color: COLORS.textPrimary, fontSize: 13, fontWeight: '600' },
});
