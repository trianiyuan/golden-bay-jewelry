// lib/queries/finances.ts
import { supabase } from '../supabase';
import { ResumenMes } from '../../types';

export async function getResumenMes(año: number, mes: number): Promise<ResumenMes> {
  const inicio = new Date(año, mes, 1).toISOString();
  const fin = new Date(año, mes + 1, 0).toISOString();
  const inicioDate = new Date(año, mes, 1).toISOString().split('T')[0];
  const finDate = new Date(año, mes + 1, 0).toISOString().split('T')[0];

  // Ventas del mes
  const { data: ventas } = await supabase
    .from('ventas')
    .select('total_cobrado')
    .gte('fecha', inicio)
    .lte('fecha', fin);

  // Gastos del mes
  const { data: gastos } = await supabase
    .from('gastos')
    .select('monto')
    .gte('fecha', inicioDate)
    .lte('fecha', finDate);

  const ingresos = (ventas || []).reduce((sum, v) => sum + Number(v.total_cobrado), 0);
  const totalGastos = (gastos || []).reduce((sum, g) => sum + Number(g.monto), 0);

  return {
    mes: `${año}-${String(mes + 1).padStart(2, '0')}`,
    total_ventas: ventas?.length || 0,
    ingresos_ventas: ingresos,
    total_gastos: totalGastos,
    ganancia: ingresos - totalGastos,
  };
}

export async function getResumenUltimosMeses(cantMeses = 6) {
  const resultados: ResumenMes[] = [];
  const hoy = new Date();

  for (let i = cantMeses - 1; i >= 0; i--) {
    const fecha = new Date(hoy.getFullYear(), hoy.getMonth() - i, 1);
    const resumen = await getResumenMes(fecha.getFullYear(), fecha.getMonth());
    resultados.push(resumen);
  }

  return resultados;
}

export async function getGastosPorCategoria(año: number, mes: number) {
  const inicio = new Date(año, mes, 1).toISOString().split('T')[0];
  const fin = new Date(año, mes + 1, 0).toISOString().split('T')[0];

  const { data, error } = await supabase
    .from('gastos')
    .select(`monto, categoria:categorias_gasto(nombre)`)
    .gte('fecha', inicio)
    .lte('fecha', fin);

  if (error) throw error;

  // Agrupar por categoría
  const agrupado: Record<string, number> = {};
  (data || []).forEach((g: any) => {
    const nombre = g.categoria?.nombre || 'Otros';
    agrupado[nombre] = (agrupado[nombre] || 0) + Number(g.monto);
  });

  return Object.entries(agrupado).map(([nombre, total]) => ({ nombre, total }));
}
