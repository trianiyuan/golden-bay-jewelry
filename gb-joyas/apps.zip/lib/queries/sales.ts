// lib/queries/sales.ts
import { supabase } from '../supabase';
import { Venta, ItemCarrito } from '../../types';

export async function getVentas(mes?: Date) {
  let query = supabase
    .from('ventas')
    .select(`*, productos:ventas_productos(*, producto:productos(*, categoria:categorias(*), talla:tallas_por_categoria(*)))`)
    .order('fecha', { ascending: false });

  if (mes) {
    const inicio = new Date(mes.getFullYear(), mes.getMonth(), 1).toISOString();
    const fin = new Date(mes.getFullYear(), mes.getMonth() + 1, 0).toISOString();
    query = query.gte('fecha', inicio).lte('fecha', fin);
  }

  const { data, error } = await query;
  if (error) throw error;
  return data as Venta[];
}

export async function registrarVenta(params: {
  cliente_nombre: string;
  notas?: string;
  metodo_entrega: 'correos_cr' | 'retiro_personal';
  costo_envio: number;
  total_recibido: number;
  carrito: ItemCarrito[];
}) {
  const productos = params.carrito.map(item => ({
    producto_id: item.producto.id,
    cantidad: item.cantidad,
    precio_unitario: item.producto.precio,
  }));

  const { data, error } = await supabase.rpc('registrar_venta', {
    p_cliente_nombre: params.cliente_nombre,
    p_notas: params.notas || null,
    p_metodo_entrega: params.metodo_entrega,
    p_costo_envio: params.costo_envio,
    p_total_recibido: params.total_recibido,
    p_productos: productos,
  });

  if (error) throw error;
  return data as string; // retorna el ID de la venta
}

// lib/queries/expenses.ts
export async function getGastos(mes?: Date) {
  let query = supabase
    .from('gastos')
    .select(`*, categoria:categorias_gasto(*)`)
    .order('fecha', { ascending: false });

  if (mes) {
    const inicio = new Date(mes.getFullYear(), mes.getMonth(), 1).toISOString().split('T')[0];
    const fin = new Date(mes.getFullYear(), mes.getMonth() + 1, 0).toISOString().split('T')[0];
    query = query.gte('fecha', inicio).lte('fecha', fin);
  }

  const { data, error } = await query;
  if (error) throw error;
  return data;
}

export async function createGasto(gasto: {
  fecha: string;
  monto: number;
  categoria_gasto_id: string;
  notas?: string;
}) {
  const { data, error } = await supabase
    .from('gastos')
    .insert(gasto)
    .select()
    .single();
  if (error) throw error;
  return data;
}

export async function getCategoriasGasto() {
  const { data, error } = await supabase
    .from('categorias_gasto')
    .select('*')
    .order('nombre');
  if (error) throw error;
  return data;
}
